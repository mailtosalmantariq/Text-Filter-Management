﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace TextFileterManagement.Services.FilterServices
{
    public class TextFillterServices : ITextFillterServices
    {
        public async Task<StringBuilder> FilterVowel(string filePath)
        {
            StringBuilder filterVowel = new();

            try
            {
                foreach (string line in File.ReadLines(filePath))
                {
                    try
                    {
                        if (!string.IsNullOrWhiteSpace(line))
                        {
                            string filteredLine = string.Join(" ", line.Split(' ').Select(FilterWord));
                            filterVowel.AppendLine(filteredLine);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"An error occurred while processing line: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while reading the file: {ex.Message}");
            }

            return await Task.FromResult(filterVowel);
        }

        public string FilterWord(string word)
        {
            string? filteredWord = new string(word.Where(char.IsLetter).ToArray());

            // Split the word into characters
            char[] characters = filteredWord.ToCharArray();

            // Find the middle character(s)
            int middleIndex = characters.Length / 2;
            bool isMiddleVowel;

            if (characters.Length % 2 == 0) // If the word length is even
                isMiddleVowel = IsVowel(characters[middleIndex - 1]) || IsVowel(characters[middleIndex]);
            else
                isMiddleVowel = IsVowel(characters[middleIndex]);

            // Filter the word based on whether the middle character is a vowel or not
            if (!isMiddleVowel)
                return word;
            else
                return string.Empty; // Filter out the word
        }

        private static bool IsVowel(char c)
        {
            // Check if the character is a vowel
            return "aeiouyAEIOUY".IndexOf(c) != -1;
        }


        public async Task<StringBuilder> FilterWordsLessThanThree(StringBuilder text)
        {
            StringBuilder filteredText = new();

            using (StringReader reader = new(text.ToString()))
            {
                string? line;
                while ((line = reader.ReadLine()) != null)
                {
                    StringBuilder filteredLine = new();

                    foreach (string word in line.Split(' ', StringSplitOptions.RemoveEmptyEntries))
                    {
                        string filteredWord = new string(word.Where(char.IsLetter).ToArray());
                        if (filteredWord.Length >= 3)
                            filteredLine.Append(word).Append(' ');
                    }

                    if (filteredLine.Length > 0)
                        filteredText.AppendLine(filteredLine.ToString().Trim());
                }
            }

            return await Task.FromResult(filteredText);
        }

        public async Task<StringBuilder> FilterT(StringBuilder text)
        {
            StringBuilder filteredText = new();

            using (StringReader reader = new(text.ToString()))
            {
                string? line;
                while ((line = reader.ReadLine()) != null)
                {
                    StringBuilder filteredLine = new();

                    foreach (string word in line.Split(' '))
                    {
                        if (!word.Contains('t', StringComparison.OrdinalIgnoreCase)) // Ignore case
                            filteredLine.Append(word).Append(' ');
                    }

                    if (filteredLine.Length > 0)
                        filteredText.AppendLine(filteredLine.ToString().TrimEnd());
                }
            }

            return await Task.FromResult(filteredText);
        }

        public async Task<bool> ValidateInputFile(string filePath)
        {
            try
            {
                if (File.Exists(filePath) && new FileInfo(filePath).Length > 0)
                    return await Task.FromResult(true);

                return await Task.FromResult(false);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return await Task.FromResult(false);
            }
        }
    }
}
