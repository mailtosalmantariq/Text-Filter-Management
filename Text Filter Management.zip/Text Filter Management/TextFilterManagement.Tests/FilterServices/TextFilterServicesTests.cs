﻿using NUnit.Framework;
using Moq;
using System.Text;
using System.Threading.Tasks;
using TextFileterManagement.Services.FilterServices;

namespace TextFilterManagement.Tests.Services.FilterServices
{
    [TestFixture]
    public class TextFilterServicesTests
    {

        private TextFillterServices textFillterServices;
        private Mock<ITextFillterServices> mockTextFillterServices;

        [SetUp]
        public void SetUp()
        {
            textFillterServices = new TextFillterServices();
            mockTextFillterServices = new Mock<ITextFillterServices>();
        }

        [Test]
        public void FilterVowel_ValidFile_ReturnsFilteredText()
        {
            string currentDirectory = Directory.GetCurrentDirectory();
            string? parentDirectory = Directory.GetParent(currentDirectory)?.Parent?.Parent?.FullName ?? "";
            string? filePath = Path.Combine(parentDirectory, "TestFile", "Text Input.txt"); // Provide a valid file path with test data

            string expectedFilteredText = "Only."; // Define expected filtered text based on test data

            //mockTextFillterServices.Setup(x => x.FilterVowel(filePath)).ReturnsAsync(new StringBuilder(expectedFilteredText));

            var getResult = textFillterServices.FilterVowel(filePath);

            string? actualResult = getResult.Result?.ToString()?.Trim();

            Assert.That(expectedFilteredText, Is.EqualTo(actualResult?.ToString()?.ToString()));
        }

        [Test]
        public void FilterWordsLessThanThree_ValidText_ReturnsFilteredText()
        {
            StringBuilder text = new StringBuilder("This is for Test Only."); // Provide valid text for testing
            string expectedFilteredText = "This for Test Only."; // Define expected filtered text based on test data

            //mockTextFillterServices.Setup(x => x.FilterWordsLessThanThree(It.IsAny<StringBuilder>())).ReturnsAsync(new StringBuilder(expectedFilteredText));

            var getResult = textFillterServices.FilterWordsLessThanThree(text);

            string? actualResult = getResult.Result?.ToString()?.Trim();

            Assert.That(expectedFilteredText, Is.EqualTo(actualResult?.ToString()));
        }

        [Test]
        public void FilterT_ValidText_ReturnsFilteredText()
        {
            StringBuilder text = new StringBuilder("This is for Test Only."); // Provide valid text for testing
            string expectedFilteredText = "is for Only."; // Define expected filtered text based on test data

            //mockTextFillterServices.Setup(x => x.FilterT(It.IsAny<StringBuilder>())).ReturnsAsync(new StringBuilder(expectedFilteredText));

            var getResult = textFillterServices.FilterT(text);

            string? actualResult = getResult.Result?.ToString()?.Trim();

            Assert.That(expectedFilteredText, Is.EqualTo(actualResult?.ToString()));
        }

        [Test]
        public async Task ValidateInputFile_ValidFile_ReturnsTrue()
        {
            string currentDirectory = Directory.GetCurrentDirectory();
            string? parentDirectory = Directory.GetParent(currentDirectory)?.Parent?.Parent?.FullName ?? "";
            string? filePath = Path.Combine(parentDirectory, "TestFile", "Text Input.txt"); // Provide a valid file path with test data

            //mockTextFillterServices.Setup(x => x.ValidateInputFile(It.IsAny<string>())).ReturnsAsync(true);

            bool isValid = await textFillterServices.ValidateInputFile(filePath);

            Assert.That(isValid, Is.True);
        }

        [Test]
        public async Task ValidateInputFile_InvalidFile_ReturnsFalse()
        {
            string filePath = "invalidFile.txt"; // Provide an invalid file path

            //mockTextFillterServices.Setup(x => x.ValidateInputFile(It.IsAny<string>())).ReturnsAsync(false);

            bool isValid = await textFillterServices.ValidateInputFile(filePath);

            Assert.That(isValid, Is.False);
        }

    }
}
