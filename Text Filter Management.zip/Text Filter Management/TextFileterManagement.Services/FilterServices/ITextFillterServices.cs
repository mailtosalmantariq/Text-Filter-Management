﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextFileterManagement.Services.FilterServices
{
    public interface ITextFillterServices
    {
        Task<StringBuilder> FilterVowel(string filePath);
        Task<StringBuilder> FilterWordsLessThanThree(StringBuilder text);
        Task<StringBuilder> FilterT(StringBuilder text);
        Task<bool> ValidateInputFile(string filePath);
    }
}
