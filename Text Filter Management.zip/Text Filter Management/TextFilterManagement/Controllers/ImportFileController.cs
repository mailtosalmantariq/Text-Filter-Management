﻿using Microsoft.AspNetCore.Mvc;
using System.Text;
using TextFileterManagement.Services.FilterServices;

namespace TextFilterManagement.Controllers
{
    public class ImportFileController : Controller
    {
        private readonly ITextFillterServices _textFillterServices;

        public ImportFileController(ITextFillterServices textFillterServices)
        {
            _textFillterServices = textFillterServices;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> PostFiles(string filePath)
        {
            try
            {
                if (string.IsNullOrEmpty(filePath))
                {
                    ViewBag.ErrorMessage = "No File Name or File Path";
                    return await Task.FromResult(View("Error"));
                }

                var validateFile = await _textFillterServices.ValidateInputFile(filePath);

                if (validateFile == true)
                {
                    var filteredVowels = await _textFillterServices.FilterVowel(filePath);
                    var filteredWordsLessThree = await _textFillterServices.FilterWordsLessThanThree(filteredVowels);
                    var filteredT = await _textFillterServices.FilterT(filteredWordsLessThree);

                    ViewBag.FilteredResult = filteredT;

                    Console.WriteLine();
                    Console.WriteLine("The result after applying filters is as follows.");
                    Console.WriteLine();
                    Console.WriteLine(filteredT);
                    
                    return await Task.FromResult(View("ShowResult"));
                    

                }
                else
                {
                    string ErrorMessage = "File is not valid. Please check the file";
                    ViewBag.ErrorMessage = ErrorMessage;
                    Console.WriteLine(ErrorMessage);
                    return await Task.FromResult(View("Error"));
                }
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = ex.Message;
                return await Task.FromResult(View("Error"));
            }
        }
    }
}
