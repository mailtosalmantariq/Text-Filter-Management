﻿document.addEventListener("DOMContentLoaded", function () {
    $('#unApprovedStagingTable').DataTable({
        "scrollY": "550px",
        "scrollCollapse": true,
        "paging": false,
        "columns": [
            { "searchable": false },   // Column 1 
            { "searchable": true },  // Column 2 
            { "searchable": true },   // Column 3 
            { "searchable": false },   // Column 4 
            { "searchable": false },   // Column 5 
            { "searchable": false },   // Column 6 
            { "searchable": false },   // Column 7 
            { "searchable": false },   // Column 8 
            { "searchable": true }   // Column 9 
        ]
    });
});

document.addEventListener("DOMContentLoaded", function () {
    $('#failedValidationTable').DataTable({
        "scrollY": "450px",
        "scrollCollapse": true,
        "paging": true,
        "searching": false
    });
});

